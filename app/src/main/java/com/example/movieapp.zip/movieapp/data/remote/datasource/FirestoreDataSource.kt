package com.example.movieapp.data.remote.datasource

import com.example.movieapp.data.remote.dto.MovieFirestoreDto
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import kotlin.random.Random

class MovieFirestoreDataSource @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth
) {

    private fun favourites() = auth.currentUser?.uid?.let { uid ->
        firestore.collection("users").document(uid).collection("favourites")
    }

    suspend fun insertMovie(movie: MovieFirestoreDto) {
        val col = favourites() ?: return
        val existing = col.whereEqualTo("movieId", movie.movieId).limit(1).get().await()
        if (!existing.isEmpty) return

        val now = System.currentTimeMillis()
        val docId = "$now${Random.nextInt(1000, 9999)}"
        col.document(docId).set(movie.copy(id = now, addedAt = now)).await()
    }

    suspend fun deleteMovieById(movieId: Int) {
        val col = favourites() ?: return
        val docs = col.whereEqualTo("movieId", movieId).get().await()
        for (doc in docs.documents) {
            doc.reference.delete().await()
        }
    }

    suspend fun isMovieSaved(movieId: Int): Boolean {
        val col = favourites() ?: return false
        return !col.whereEqualTo("movieId", movieId).limit(1).get().await().isEmpty
    }

    fun getAllMovies(): Flow<List<MovieFirestoreDto>> {
        return callbackFlow {
            val col = favourites()
            if (col == null) {
                trySend(emptyList())
                close()
                return@callbackFlow
            }

            val listener = col
                .orderBy("addedAt", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) {
                        trySend(emptyList())
                        return@addSnapshotListener
                    }
                    trySend(snapshot.toObjects(MovieFirestoreDto::class.java))
                }

            awaitClose { listener.remove() }
        }
    }
}