package com.example.movieapp.data.remote.dto

import com.google.gson.annotations.SerializedName

data class ReleaseDatesResultDto(
    @SerializedName("results") val results: List<CountryReleaseDto>
)